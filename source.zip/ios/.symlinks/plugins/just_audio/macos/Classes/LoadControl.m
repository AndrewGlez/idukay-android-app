#import "LoadControl.h"

@implementation LoadControl
@synthesize preferredForwardBufferDuration;
@synthesize canUseNetworkResourcesForLiveStreamingWhilePaused;
@synthesize preferredPeakBitRate;
@end
