# package_info_plus_example

Demonstrates how to use the package_info_plus plugin.
